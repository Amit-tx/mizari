# Mizari — Your Link in Bio

A modern link-in-bio platform built with Next.js 15, Tailwind CSS v4, Drizzle ORM, and Neon Postgres.

## Tech Stack

- **Framework**: Next.js 15 (App Router, TypeScript)
- **Styling**: Tailwind CSS v4
- **Database**: Neon Postgres (serverless)
- **ORM**: Drizzle ORM
- **Auth**: NextAuth.js v5 (Auth.js) — Credentials + Google OAuth
- **Deployment**: Vercel

## Getting Started

### Prerequisites

- Node.js 18+
- A [Neon](https://neon.tech) Postgres database

### Setup

1. **Clone and install:**
   ```bash
   git clone <your-repo>
   cd mizari
   npm install
   ```

2. **Configure environment variables:**
   Copy `.env.local` and fill in your values:
   ```
   DATABASE_URL=postgresql://...        # From Neon dashboard
   AUTH_SECRET=<random-32-byte-base64>  # Run: openssl rand -base64 32
   AUTH_URL=http://localhost:3000
   AUTH_GOOGLE_ID=<optional>
   AUTH_GOOGLE_SECRET=<optional>
   ```

3. **Push database schema:**
   ```bash
   npx drizzle-kit push
   ```

4. **Run the dev server:**
   ```bash
   npm run dev
   ```

5. Open [http://localhost:3000](http://localhost:3000)

## Project Structure

```
src/
├── app/
│   ├── layout.tsx           # Root layout (Header, Footer, Theme, Auth)
│   ├── page.tsx             # Landing page
│   ├── [username]/          # Public profile pages
│   ├── (auth)/              # Login & Signup pages
│   ├── dashboard/           # Protected dashboard
│   └── api/
│       ├── auth/            # NextAuth routes + signup
│       └── click/           # Click tracking redirect
├── components/              # Reusable UI components
├── db/                      # Drizzle schema & connection
├── auth.ts                  # NextAuth configuration
└── middleware.ts            # Route protection
```

## Features

- 🔗 **Custom Links** — Add, edit, delete, and reorder your links
- 📊 **Click Analytics** — Track clicks on each link
- 🌙 **Dark Mode** — Smooth theme switching with system preference detection
- 🔒 **Authentication** — Email/password + Google OAuth
- 📱 **Responsive** — Mobile-first design, works on all devices
- 📢 **Ad Slots** — Reserved ad placement zones for monetization

## Deployment

Deploy to Vercel:

```bash
npx vercel
```

Set the same environment variables in your Vercel project settings.

## License

MIT
