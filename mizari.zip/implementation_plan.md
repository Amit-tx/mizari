# Implementation Plan: Mizari Enterprise Upgrades

Boring Linktree profiles ko beat karne ke liye Mizari ko Multiple Profiles, Gamified Levels, Reacting system aur 10+ new seasonal themes se equip karenge.

## Proposed Changes

### 1. Database Schema Refactor
- [x] Refactored [schema.ts](file:///C:/Users/AMIT/.gemini/antigravity/scratch/mizari/src/db/schema.ts) to support `profiles` table.
- [ ] Shift links and wishes foreign keys to `profileId`.
- [ ] Add `likes` (reactions) column to `profiles`.
- [ ] Run `npx drizzle-kit push --force` to migrate.

### 2. Authentication & Signup Adaptation
- [ ] Update [signup/route.ts](file:///C:/Users/AMIT/.gemini/antigravity/scratch/mizari/src/app/api/auth/signup/route.ts) to automatically create a default "personal" profile on signup.
- [ ] Update [auth.ts](file:///C:/Users/AMIT/.gemini/antigravity/scratch/mizari/src/auth.ts) to attach profile IDs to sessions.

### 3. Themes Upgrade (10+ New Themes)
- [ ] Add new Japanese & Seasonal themes in `src/components/Themes.ts`.
- [ ] Implement falling maple leaves animation for Autumn (🍁 Aki).
- [ ] Implement falling snow animation for Winter (❄️ Fuyu).
- [ ] Implement floating lanterns for Summer Festival (🏮 Matsuri).

### 4. Multiple Profile Switcher & Creator Levels
- [ ] Update [actions.ts](file:///C:/Users/AMIT/.gemini/antigravity/scratch/mizari/src/app/dashboard/actions.ts) to support creating and switching profiles.
- [ ] Add profile selector dropdown in [DashboardClient.tsx](file:///C:/Users/AMIT/.gemini/antigravity/scratch/mizari/src/app/dashboard/DashboardClient.tsx).
- [ ] Display Creator Level (Level 1 to 10) based on total clicks on dashboard.

### 5. Reactions & HTML5 Drag and Drop
- [ ] Add floating Like / Reaction button on public profile page.
- [ ] Create a React action to increment likes without page reload.
- [ ] Enable HTML5 drag-and-drop handles in dashboard links list.

---
**Verification**: We will run `npx tsc --noEmit` and locally verify the profile switcher and animations.
